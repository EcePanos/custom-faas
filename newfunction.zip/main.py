def main(data):
    return data
